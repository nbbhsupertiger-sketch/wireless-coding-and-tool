//****************************************************************
//                      FT60F011A
//                   ---------------
//           VDD  -1-|VDD         VSS|-8-  GND 
//           KEY  -2-|PA2         PA4|-7-  RFDAT 
//       ICSPDAT  -3-|PA1         PA5|-6-  LED
//            NC  -4-|PA3         PA0|-5-  ICSPCLK
//                   ---------------
//*****************************************************************

//-----------------------------------------------------------------
// Ӳ�����Ŷ���
//-----------------------------------------------------------------
#define     KEY             PA2                 // ��������
#define     RFDAT           PA4                 // �������
#define     LED             PA5                 // LEDָʾ�����

//-----------------------------------------------------------------
// ״̬���ƺ궨��
//-----------------------------------------------------------------
#define     LED_OFF         (LED = 0)           // LED Ϩ��(�͵�ƽ)
#define     LED_ON          (LED = 1)           // LED ����(�ߵ�ƽ)
#define     LED_CPL         (LED = !LED)        // LED ״̬��ת

#define     RFDAT_LOW       (RFDAT = 0)         // ��������͵�ƽ
#define     RFDAT_HIGH      (RFDAT = 1)         // ��������ߵ�ƽ

//-----------------------------------------------------------------
// ��������
//-----------------------------------------------------------------
void        Sys_Init        (void);
void        DelayUs         (unsigned char Time);
void        DelayMs         (unsigned char Time);

void        coding_syn_1527 (void);
void        coding_L_1527   (void);
void        coding_H_1527   (void);
void        coding_1527     (unsigned long Temp_Data);
void 		bag_1527		(unsigned long Data,unsigned int frame_num,unsigned int slp_time);